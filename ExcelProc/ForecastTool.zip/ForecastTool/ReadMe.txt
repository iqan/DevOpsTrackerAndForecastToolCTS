Import:
	Import .xlsx file only

Export:
	File name should be different.(name should not be same as existing file)

---------------------------------------

From Date:
	If no from date is selected, it will take current date.

To Date:
	If no to date is selected, it will take billing period end date of november.


---------------------------------------

If you want to add extensions, add a new coloumn in SOW tracker file after "Uploaded in ARC?" coloumn.

You will get rows for extended resources in Pink color.